import unittest

from fastapi.testclient import TestClient

from backend.app.main import app


class ApiWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)

    def login(self, username: str, password: str) -> dict:
        response = self.client.post("/api/auth/login", json={"username": username, "password": password})
        self.assertEqual(response.status_code, 200)
        return {"Authorization": f"Bearer {response.json()['access_token']}"}

    def test_complete_least_privilege_workflow(self):
        analyst = self.login("analyst", "Analyst123!")
        sample = self.client.get("/api/telemetry/sample?limit=100", headers=analyst)
        self.assertEqual(sample.status_code, 200)
        weak_record = next(item for item in sample.json()["records"] if item["downlink_kbps"] < 100 and item["rsrp"] < -100)

        investigation = self.client.post("/api/incidents/investigate", headers=analyst, json={"record": weak_record, "untrusted_context": []})
        self.assertEqual(investigation.status_code, 200)
        action_id = investigation.json()["proposed_action"]["id"]

        denied = self.client.post(f"/api/actions/{action_id}/approve", headers=analyst)
        self.assertEqual(denied.status_code, 403)

        engineer = self.login("engineer", "Engineer123!")
        approved = self.client.post(f"/api/actions/{action_id}/approve", headers=engineer)
        self.assertEqual(approved.status_code, 200)

        denied_execution = self.client.post(f"/api/actions/{action_id}/execute-simulation", headers=engineer)
        self.assertEqual(denied_execution.status_code, 403)

        admin = self.login("admin", "Admin123!")
        executed = self.client.post(f"/api/actions/{action_id}/execute-simulation", headers=admin)
        self.assertEqual(executed.status_code, 200)
        self.assertEqual(executed.json()["status"], "simulated")

    def test_evaluation_requires_engineer_role(self):
        analyst = self.login("analyst", "Analyst123!")
        self.assertEqual(self.client.post("/api/evaluations/run", headers=analyst).status_code, 403)
        engineer = self.login("engineer", "Engineer123!")
        response = self.client.post("/api/evaluations/run", headers=engineer)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["summary"]["safety_violations"], 0)


if __name__ == "__main__":
    unittest.main()
