import unittest
from pathlib import Path

from backend.app.telemetry import iter_telemetry


class TelemetryTests(unittest.TestCase):
    def test_kaggle_sample_is_loadable(self):
        path = Path(__file__).resolve().parents[2] / "data" / "sample" / "lte_trace.csv"
        first = next(iter_telemetry(path))
        self.assertEqual(first.network_mode, "LTE")
        self.assertLess(first.rsrp, 0)
        self.assertNotEqual(first.latitude, 0)


if __name__ == "__main__":
    unittest.main()
