"""Telecom Guardian backend package."""
