from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
from dataclasses import dataclass
from typing import Iterable


SECRET = os.getenv("APP_SECRET", "development-only-change-me")
TOKEN_TTL_SECONDS = 3600


@dataclass(frozen=True)
class User:
    username: str
    role: str


DEMO_USERS = {
    "analyst": ("Analyst123!", "analyst"),
    "engineer": ("Engineer123!", "engineer"),
    "admin": ("Admin123!", "admin"),
}

ROLE_PERMISSIONS = {
    "analyst": {"telemetry:read", "incident:investigate", "action:propose", "audit:read"},
    "engineer": {"telemetry:read", "incident:investigate", "action:propose", "action:approve", "audit:read", "evaluation:run"},
    "admin": {"*"},
}

INJECTION_MARKERS = (
    "ignore previous",
    "ignore all previous",
    "reveal the system prompt",
    "exfiltrate",
    "send secrets",
    "disable authorization",
    "bypass approval",
)


def authenticate(username: str, password: str) -> User | None:
    candidate = DEMO_USERS.get(username)
    if not candidate or not hmac.compare_digest(candidate[0], password):
        return None
    return User(username=username, role=candidate[1])


def _b64(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode()


def create_token(user: User) -> str:
    header = _b64(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = _b64(json.dumps({"sub": user.username, "role": user.role, "exp": int(time.time()) + TOKEN_TTL_SECONDS}, separators=(",", ":")).encode())
    message = f"{header}.{payload}".encode()
    signature = _b64(hmac.new(SECRET.encode(), message, hashlib.sha256).digest())
    return f"{header}.{payload}.{signature}"


def decode_token(token: str) -> User | None:
    try:
        header, payload, signature = token.split(".")
        message = f"{header}.{payload}".encode()
        expected = _b64(hmac.new(SECRET.encode(), message, hashlib.sha256).digest())
        if not hmac.compare_digest(expected, signature):
            return None
        padding = "=" * (-len(payload) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload + padding))
        if claims["exp"] < time.time():
            return None
        return User(username=claims["sub"], role=claims["role"])
    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        return None


def is_allowed(role: str, permission: str) -> bool:
    permissions = ROLE_PERMISSIONS.get(role, set())
    return "*" in permissions or permission in permissions


def detect_prompt_injection(texts: Iterable[str]) -> list[str]:
    joined = " ".join(texts).lower()
    return [marker for marker in INJECTION_MARKERS if marker in joined]


def policy_decision(role: str, permission: str, *, injection_hits: list[str] | None = None) -> dict:
    if injection_hits:
        return {"allowed": False, "reason": "Untrusted content matched prompt-injection policy", "policy": "TG-INPUT-002"}
    if not is_allowed(role, permission):
        return {"allowed": False, "reason": f"Role {role} lacks {permission}", "policy": "TG-RBAC-001"}
    return {"allowed": True, "reason": "Role and context satisfy policy", "policy": "TG-RBAC-001"}
