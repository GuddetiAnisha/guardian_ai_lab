from __future__ import annotations

from dataclasses import asdict

from .audit import AuditRepository
from .llm import grounded_reasoning
from .rag import retrieve
from .security import User, detect_prompt_injection, policy_decision
from .telemetry import TelemetryRecord, classify_anomaly


class TelecomAgent:
    """Evidence-first agent with explicit tool and authorization boundaries."""

    def __init__(self, repository: AuditRepository):
        self.repository = repository

    def investigate(self, user: User, record: TelemetryRecord, untrusted_context: list[str] | None = None) -> dict:
        hits = detect_prompt_injection(untrusted_context or [])
        decision = policy_decision(user.role, "incident:investigate", injection_hits=hits)
        incident = classify_anomaly(record)
        resource = incident["incident_id"] if incident else f"TELEMETRY-{record.sequence}"
        self.repository.record(actor=user.username, role=user.role, event_type="agent.investigate", resource=resource, decision="allow" if decision["allowed"] else "deny", policy=decision["policy"], details={"prompt_injection_hits": hits})
        if not decision["allowed"]:
            return {"status": "blocked", "policy_decision": decision, "tool_trace": []}
        if not incident:
            return {"status": "healthy", "record": asdict(record), "tool_trace": ["telemetry.read"]}
        query = f"{incident['summary']} RSRP {record.rsrp} RSRQ {record.rsrq} SNR {record.snr} throughput {record.downlink_kbps}"
        evidence = retrieve(query)
        rationale = grounded_reasoning(incident=incident, evidence=evidence)
        action_text = evidence[0]["safe_action"] if evidence else "Collect additional evidence and request engineer review."
        action = self.repository.create_action(incident["incident_id"], action_text, user.username)
        return {
            "status": "approval_required",
            "incident": incident,
            "evidence": evidence,
            "rationale": rationale,
            "proposed_action": action,
            "policy_decision": decision,
            "tool_trace": ["telemetry.read", "runbook.retrieve", "action.propose"],
        }

    def approve(self, user: User, action_id: str) -> dict:
        decision = policy_decision(user.role, "action:approve")
        self.repository.record(actor=user.username, role=user.role, event_type="action.approve", resource=action_id, decision="allow" if decision["allowed"] else "deny", policy=decision["policy"])
        if not decision["allowed"]:
            return {"status": "blocked", "policy_decision": decision}
        item = self.repository.get_action(action_id)
        if not item:
            return {"status": "not_found"}
        return {"status": "approved", "action": self.repository.update_action(action_id, "approved", user.username), "policy_decision": decision}

    def execute_simulation(self, user: User, action_id: str) -> dict:
        item = self.repository.get_action(action_id)
        decision = policy_decision(user.role, "action:execute")
        if item and item["status"] != "approved":
            decision = {"allowed": False, "reason": "Action has no valid human approval", "policy": "TG-HITL-003"}
        self.repository.record(actor=user.username, role=user.role, event_type="action.execute_simulation", resource=action_id, decision="allow" if decision["allowed"] else "deny", policy=decision["policy"])
        if not decision["allowed"]:
            return {"status": "blocked", "policy_decision": decision}
        return {"status": "simulated", "action": self.repository.update_action(action_id, "simulated_executed"), "policy_decision": decision}
