from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .agent import TelecomAgent
from .audit import AuditRepository
from .evaluation import run_suite
from .security import User, authenticate, create_token, decode_token, policy_decision
from .telemetry import TelemetryRecord, classify_anomaly, replay


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATASET_PATH = Path(os.getenv("DATASET_PATH", PROJECT_ROOT / "data" / "sample" / "lte_trace.csv"))
repository = AuditRepository(Path(os.getenv("DATABASE_PATH", PROJECT_ROOT / "work" / "telecom_guardian.db")))
agent = TelecomAgent(repository)

app = FastAPI(title="Telecom Guardian API", version="1.0.0", description="Secure telecom agent and evaluation API")
app.add_middleware(CORSMiddleware, allow_origins=[origin.strip() for origin in os.getenv("CORS_ORIGINS", "http://localhost:8000").split(",")], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


class LoginRequest(BaseModel):
    username: str
    password: str


class TelemetryInput(BaseModel):
    sequence: int = 1
    source_timestamp: str = ""
    operator: str = "unknown"
    cell_id: str = "unknown"
    network_mode: str = "LTE"
    mobility: str = "unknown"
    latitude: float = 0
    longitude: float = 0
    speed_kmh: float = 0
    rsrp: float
    rsrq: float
    snr: float
    cqi: float = 0
    downlink_kbps: float = 0
    uplink_kbps: float = 0


class InvestigateRequest(BaseModel):
    record: TelemetryInput
    untrusted_context: list[str] = Field(default_factory=list)


def current_user(authorization: str = Header(default="")) -> User:
    prefix = "Bearer "
    user = decode_token(authorization[len(prefix):]) if authorization.startswith(prefix) else None
    if not user:
        raise HTTPException(status_code=401, detail="Missing or invalid access token")
    return user


def require(permission: str):
    def dependency(user: User = Depends(current_user)) -> User:
        decision = policy_decision(user.role, permission)
        if not decision["allowed"]:
            repository.record(actor=user.username, role=user.role, event_type="api.authorization", resource=permission, decision="deny", policy=decision["policy"])
            raise HTTPException(status_code=403, detail=decision)
        return user
    return dependency


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "dataset_ready": DATASET_PATH.exists(), "execution_mode": "simulated_actions"}


@app.post("/api/auth/login")
def login(body: LoginRequest) -> dict:
    user = authenticate(body.username, body.password)
    if not user:
        repository.record(actor=body.username, role="unknown", event_type="auth.login", resource="session", decision="deny", policy="TG-AUTH-001")
        raise HTTPException(status_code=401, detail="Invalid credentials")
    repository.record(actor=user.username, role=user.role, event_type="auth.login", resource="session", decision="allow", policy="TG-AUTH-001")
    return {"access_token": create_token(user), "token_type": "bearer", "user": {"username": user.username, "role": user.role}}


@app.get("/api/telemetry/sample")
def telemetry_sample(limit: int = Query(default=50, ge=1, le=500), user: User = Depends(require("telemetry:read"))) -> dict:
    iterator = replay(DATASET_PATH)
    records = [next(iterator).to_dict() for _ in range(limit)]
    repository.record(actor=user.username, role=user.role, event_type="telemetry.read", resource="kaggle-lte-trace", decision="allow", policy="TG-DATA-001", details={"records": limit})
    return {"source": "Beyond Throughput 4G LTE Dataset", "records": records}


@app.get("/api/telemetry/stream")
async def telemetry_stream(speed: int = Query(default=5, ge=1, le=50), user: User = Depends(require("telemetry:read"))):
    iterator = replay(DATASET_PATH)

    async def generate():
        for _ in range(1000):
            item = next(iterator)
            payload = {"telemetry": item.to_dict(), "anomaly": classify_anomaly(item)}
            yield f"data: {json.dumps(payload)}\n\n"
            await asyncio.sleep(1 / speed)

    repository.record(actor=user.username, role=user.role, event_type="telemetry.stream", resource="kaggle-lte-trace", decision="allow", policy="TG-DATA-001", details={"speed": speed})
    return StreamingResponse(generate(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/api/incidents/investigate")
def investigate(body: InvestigateRequest, user: User = Depends(require("incident:investigate"))) -> dict:
    return agent.investigate(user, TelemetryRecord(**body.record.model_dump()), body.untrusted_context)


@app.post("/api/actions/{action_id}/approve")
def approve(action_id: str, user: User = Depends(current_user)) -> dict:
    result = agent.approve(user, action_id)
    if result["status"] == "blocked":
        raise HTTPException(status_code=403, detail=result)
    if result["status"] == "not_found":
        raise HTTPException(status_code=404, detail=result)
    return result


@app.post("/api/actions/{action_id}/execute-simulation")
def execute_simulation(action_id: str, user: User = Depends(current_user)) -> dict:
    result = agent.execute_simulation(user, action_id)
    if result["status"] == "blocked":
        raise HTTPException(status_code=403, detail=result)
    return result


@app.get("/api/audit")
def audit(limit: int = Query(default=100, ge=1, le=500), _: User = Depends(require("audit:read"))) -> dict:
    return {"events": repository.list_events(limit)}


@app.post("/api/evaluations/run")
def evaluate(user: User = Depends(require("evaluation:run"))) -> dict:
    result = run_suite()
    repository.record(actor=user.username, role=user.role, event_type="evaluation.run", resource=result["run_id"], decision="allow", policy="TG-EVAL-001", details=result["summary"])
    return result


app.mount("/", StaticFiles(directory=PROJECT_ROOT / "dist", html=True), name="dashboard")
