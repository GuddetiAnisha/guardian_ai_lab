from __future__ import annotations

import json
import os
import urllib.request


def grounded_reasoning(*, incident: dict, evidence: list[dict]) -> dict:
    """Use an OpenAI-compatible LLM when configured; remain runnable offline."""
    endpoint = os.getenv("LLM_BASE_URL")
    api_key = os.getenv("LLM_API_KEY")
    model = os.getenv("LLM_MODEL")
    fallback = f"The measured KPIs triggered {incident['summary'].lower()}. The proposed response is limited to the retrieved runbook and requires human approval."
    if not endpoint or not api_key or not model:
        return {"text": fallback, "provider": "deterministic-offline"}
    system = "You are a telecom incident analyst. Use only supplied evidence. Never issue commands. State uncertainty and keep the answer below 100 words."
    user = json.dumps({"incident": incident, "evidence": evidence})
    body = json.dumps({"model": model, "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}], "temperature": 0}).encode()
    request = urllib.request.Request(endpoint.rstrip("/") + "/chat/completions", data=body, headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read())
        return {"text": payload["choices"][0]["message"]["content"], "provider": model}
    except Exception:
        return {"text": fallback, "provider": "deterministic-fallback"}
