from __future__ import annotations

import csv
import glob
import itertools
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterator


@dataclass(frozen=True)
class TelemetryRecord:
    sequence: int
    source_timestamp: str
    operator: str
    cell_id: str
    network_mode: str
    mobility: str
    latitude: float
    longitude: float
    speed_kmh: float
    rsrp: float
    rsrq: float
    snr: float
    cqi: float
    downlink_kbps: float
    uplink_kbps: float

    def to_dict(self) -> dict:
        return asdict(self)


def _number(value: str, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def discover_csvs(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    return [Path(item) for item in glob.glob(str(path / "**" / "*.csv"), recursive=True)]


def iter_telemetry(path: Path) -> Iterator[TelemetryRecord]:
    sequence = 0
    for csv_path in discover_csvs(path):
        mobility = csv_path.parent.name
        with csv_path.open(encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                sequence += 1
                yield TelemetryRecord(
                    sequence=sequence,
                    source_timestamp=row.get("Timestamp", ""),
                    operator=row.get("Operatorname", "unknown"),
                    cell_id=row.get("CellID", "unknown"),
                    network_mode=row.get("NetworkMode", "unknown"),
                    mobility=mobility,
                    latitude=_number(row.get("Latitude", "0")),
                    longitude=_number(row.get("Longitude", "0")),
                    speed_kmh=_number(row.get("Speed", "0")),
                    rsrp=_number(row.get("RSRP", "0")),
                    rsrq=_number(row.get("RSRQ", "0")),
                    snr=_number(row.get("SNR", "0")),
                    cqi=_number(row.get("CQI", "0")),
                    downlink_kbps=_number(row.get("DL_bitrate", "0")),
                    uplink_kbps=_number(row.get("UL_bitrate", "0")),
                )


def replay(path: Path) -> Iterator[TelemetryRecord]:
    records = list(iter_telemetry(path))
    if not records:
        return iter(())
    return itertools.cycle(records)


def classify_anomaly(record: TelemetryRecord) -> dict | None:
    reasons: list[str] = []
    severity = "low"
    if record.rsrp <= -115:
        reasons.append("critical RSRP")
        severity = "critical"
    elif record.rsrp <= -105:
        reasons.append("weak RSRP")
        severity = "high"
    if record.rsrq <= -15:
        reasons.append("poor RSRQ")
        severity = "critical" if record.rsrq <= -18 else max_severity(severity, "high")
    if record.snr < 0:
        reasons.append("negative SNR")
        severity = max_severity(severity, "high")
    if record.downlink_kbps < 100 and record.rsrp < -100:
        reasons.append("throughput collapse")
        severity = max_severity(severity, "medium")
    if not reasons:
        return None
    return {
        "incident_id": f"INC-{record.sequence:06d}",
        "severity": severity,
        "summary": ", ".join(reasons).capitalize(),
        "record": record.to_dict(),
    }


def max_severity(current: str, candidate: str) -> str:
    order = {"low": 0, "medium": 1, "high": 2, "critical": 3}
    return candidate if order[candidate] > order[current] else current
