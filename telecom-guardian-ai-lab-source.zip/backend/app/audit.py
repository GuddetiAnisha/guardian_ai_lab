from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from contextlib import closing
from pathlib import Path


class AuditRepository:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self._lock = threading.Lock()
        with closing(self._connect()) as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS audit_events (id TEXT PRIMARY KEY, occurred_at REAL, actor TEXT, role TEXT, event_type TEXT, resource TEXT, decision TEXT, policy TEXT, details TEXT)")
            connection.execute("CREATE TABLE IF NOT EXISTS actions (id TEXT PRIMARY KEY, incident_id TEXT, action TEXT, status TEXT, proposed_by TEXT, approved_by TEXT, created_at REAL, updated_at REAL)")
            connection.commit()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, check_same_thread=False)
        connection.row_factory = sqlite3.Row
        return connection

    def record(self, *, actor: str, role: str, event_type: str, resource: str, decision: str, policy: str, details: dict | None = None) -> dict:
        event = {"id": str(uuid.uuid4()), "occurred_at": time.time(), "actor": actor, "role": role, "event_type": event_type, "resource": resource, "decision": decision, "policy": policy, "details": details or {}}
        with self._lock, closing(self._connect()) as connection:
            connection.execute("INSERT INTO audit_events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (*[event[key] for key in ("id", "occurred_at", "actor", "role", "event_type", "resource", "decision", "policy")], json.dumps(event["details"])))
            connection.commit()
        return event

    def list_events(self, limit: int = 100) -> list[dict]:
        with closing(self._connect()) as connection:
            rows = connection.execute("SELECT * FROM audit_events ORDER BY occurred_at DESC LIMIT ?", (limit,)).fetchall()
        return [{**dict(row), "details": json.loads(row["details"])} for row in rows]

    def create_action(self, incident_id: str, action: str, proposed_by: str) -> dict:
        now = time.time()
        item = {"id": f"ACT-{uuid.uuid4().hex[:8].upper()}", "incident_id": incident_id, "action": action, "status": "pending_approval", "proposed_by": proposed_by, "approved_by": None, "created_at": now, "updated_at": now}
        with self._lock, closing(self._connect()) as connection:
            connection.execute("INSERT INTO actions VALUES (?, ?, ?, ?, ?, ?, ?, ?)", tuple(item.values()))
            connection.commit()
        return item

    def get_action(self, action_id: str) -> dict | None:
        with closing(self._connect()) as connection:
            row = connection.execute("SELECT * FROM actions WHERE id = ?", (action_id,)).fetchone()
        return dict(row) if row else None

    def update_action(self, action_id: str, status: str, approved_by: str | None = None) -> dict | None:
        with self._lock, closing(self._connect()) as connection:
            connection.execute("UPDATE actions SET status = ?, approved_by = COALESCE(?, approved_by), updated_at = ? WHERE id = ?", (status, approved_by, time.time(), action_id))
            connection.commit()
        return self.get_action(action_id)
