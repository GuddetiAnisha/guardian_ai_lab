"""Download and prepare the public Kaggle 4G LTE trace used by the project."""

from __future__ import annotations

import shutil
import ssl
import tempfile
import urllib.request
import zipfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATASET_URL = "https://www.kaggle.com/api/v1/datasets/download/aeryss/lte-dataset"
DESTINATION = PROJECT_ROOT / "data" / "sample" / "lte_trace.csv"
PREFERRED_TRACE = "Dataset/bus/A_2017.11.30_16.48.26.csv"


def main() -> None:
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temp_dir:
        archive = Path(temp_dir) / "lte-dataset.zip"
        request = urllib.request.Request(DATASET_URL, headers={"User-Agent": "telecom-guardian/1.0"})
        context = ssl.create_default_context()
        with urllib.request.urlopen(request, context=context, timeout=90) as response, archive.open("wb") as target:
            shutil.copyfileobj(response, target)
        with zipfile.ZipFile(archive) as bundle:
            try:
                source = bundle.open(PREFERRED_TRACE)
            except KeyError as error:
                candidates = [name for name in bundle.namelist() if name.lower().endswith(".csv")]
                if not candidates:
                    raise RuntimeError("The Kaggle archive contained no CSV traces") from error
                source = bundle.open(candidates[0])
            with source, DESTINATION.open("wb") as target:
                shutil.copyfileobj(source, target)
    (PROJECT_ROOT / "dist" / "data").mkdir(parents=True, exist_ok=True)
    shutil.copy2(DESTINATION, PROJECT_ROOT / "dist" / "data" / "lte_trace.csv")
    print(f"Prepared {DESTINATION.relative_to(PROJECT_ROOT)}")


if __name__ == "__main__":
    main()
