# Telecom Guardian AI Lab

A portfolio-ready implementation of two Agentic AI research areas:

1. **Agentic AI Security** — authenticated identities, least-privilege authorization, delegated actions, human approval, prompt-injection filtering, and accountable tool execution.
2. **Agentic AI Evaluation** — reproducible task, safety, tool-use, latency, and adversarial test scenarios with scenario-level evidence.

The system turns genuine one-second LTE measurements into a reproducible live operations stream. A constrained agent detects radio problems, retrieves a relevant runbook, explains its evidence, and stages a safe remediation. No network action can run without policy checks and human approval, and all execution is simulated.

> Portfolio prototype only. This project is not affiliated with Ericsson and must not be connected to a production telecom network without a full security and operational review.

## Why this problem matters

Telecom operations teams process high-volume telemetry while following strict change controls. An unconstrained LLM can select the wrong tool, trust malicious retrieved content, expose sensitive data, or perform an action beyond the operator's authority. Telecom Guardian makes those boundaries visible and testable.

## Architecture

```mermaid
flowchart LR
    D[4G LTE Kaggle trace] --> R[Replay service]
    R --> A[Anomaly detector]
    A --> G[Constrained telecom agent]
    B[Local runbooks] --> G
    G --> P{Policy engine}
    U[Authenticated user] --> P
    P -->|allow proposal| H[Human approval]
    P -->|deny| L[Audit log]
    H --> S[Simulated action tool]
    S --> L
    E[Evaluation runner] --> A
    E --> G
    E --> P
    L --> UI[Operations and evaluation UI]
```

The hosted dashboard runs completely in the browser for safe demonstration. The local FastAPI service provides the full authenticated API, SSE replay stream, SQLite audit persistence, agent workflow, optional LLM reasoning adapter, and automated evaluation endpoints.

## Implemented capabilities

### Secure operations agent

- HMAC-signed JWT sessions for demo analyst, engineer, and administrator identities.
- Role-based permissions for telemetry, investigation, proposal, approval, execution, evaluation, and audit access.
- Explicit separation of human identity and the delegated `agent:triage` actor.
- Prompt-injection detection before untrusted context reaches retrieval or tools.
- Local runbook retrieval with source IDs and evidence excerpts.
- Human approval checkpoint before every sensitive action.
- Administrator-only execution, limited to a non-destructive simulation.
- SQLite records for authentication, data access, policy decisions, approvals, and tool execution.
- Optional OpenAI-compatible LLM reasoning with a deterministic offline fallback.

### Evaluation and red-team platform

- Deterministic security, authorization, anomaly-detection, and robustness scenarios.
- Scenario-level expected versus observed results.
- Task success, safety violations, tool accuracy, and latency metrics.
- Adversarial tests for instruction injection and authorization bypass attempts.
- Unit tests that verify token integrity, RBAC, injection blocking, runbook evidence, approval gates, and dataset loading.
- Downloadable evaluation and audit evidence from the dashboard.

## Dataset

The included sample comes from the Kaggle [4G LTE Speed Dataset and Bandwidth](https://www.kaggle.com/datasets/aeryss/lte-dataset), licensed CC BY-SA 4.0. It accompanies the paper “Beyond Throughput: a 4G LTE Dataset with Channel and Context Metrics” and contains real mobile measurements such as RSRP, RSRQ, SNR, CQI, throughput, movement speed, and cell identifiers.

Kaggle records are historical. The application preserves their order and replays them at 1×, 5×, or 20× speed. This is a realistic stream simulation, not a claim of access to a live operator network. See [DATASET.md](DATASET.md) for attribution and limitations.

Refresh the sample from Kaggle with:

```bash
python scripts/download_kaggle_data.py
```

## Run the complete application

The simplest route is Docker:

```bash
docker compose up --build
```

Open `http://localhost:8000`. API documentation is available at `http://localhost:8000/docs`.

Alternatively, use Python 3.11 or later:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r backend/requirements-dev.txt
uvicorn backend.app.main:app --reload
```

### Demo users

| Username | Password | Role | Key boundary |
|---|---|---|---|
| `analyst` | `Analyst123!` | Analyst | Investigates and proposes; cannot approve |
| `engineer` | `Engineer123!` | Engineer | Can approve; cannot execute |
| `admin` | `Admin123!` | Administrator | Can approve and execute simulations |

These credentials exist only for local demonstration. Replace the demo identity provider and `APP_SECRET` before any non-local deployment.

### Optional LLM configuration

The project works without an API key. To compare deterministic and LLM-assisted reasoning, configure any compatible chat-completions endpoint:

```text
LLM_BASE_URL=https://your-provider.example/v1
LLM_API_KEY=...
LLM_MODEL=...
```

The LLM can produce only a grounded rationale. It cannot bypass the policy engine, grant approval, or call the execution tool.

## API surface

| Method | Endpoint | Purpose |
|---|---|---|
| `POST` | `/api/auth/login` | Create an identity-bound access token |
| `GET` | `/api/telemetry/sample` | Read replay records within delegated scope |
| `GET` | `/api/telemetry/stream` | Stream records as server-sent events |
| `POST` | `/api/incidents/investigate` | Run detection, retrieval, reasoning, and proposal |
| `POST` | `/api/actions/{id}/approve` | Create a human approval decision |
| `POST` | `/api/actions/{id}/execute-simulation` | Execute the safe simulated tool |
| `GET` | `/api/audit` | Read accountability records |
| `POST` | `/api/evaluations/run` | Run the deterministic benchmark |

## Test and verify

```bash
python -m unittest discover -s backend/tests -v
node --check dist/app.js
```

CI runs the same checks on pushes and pull requests.

## Repository structure

```text
backend/app/          FastAPI API, agent, RAG, security, telemetry and evaluation
backend/tests/        Security, agent and dataset tests
data/sample/          Attributed LTE trace used by the backend
dist/                 Dependency-free interactive dashboard and hosted demo
scripts/              Reproducible Kaggle data preparation
.github/workflows/    Continuous integration
Dockerfile            Non-root production-style container
docker-compose.yml    One-command local environment
```

## Demonstration script

1. Watch genuine LTE records populate the live signal chart and anomaly queue.
2. Select an incident and explain the agent's observe → retrieve → reason → authorize trace.
3. Attempt approval as Analyst and show the denial in the audit trail.
4. Switch to Engineer to approve, then Administrator to execute the safe simulation.
5. Paste an injection attempt into the security scanner and show that it is blocked before retrieval.
6. Run the 32-scenario evaluation suite and inspect the two deliberately surfaced reliability failures.

## Suggested résumé bullets

- Built a secure agentic telecom operations platform using Python, FastAPI, JavaScript, SQLite, SSE, RAG, Docker, JWT authentication, RBAC, and human-in-the-loop approval over real LTE mobility traces.
- Developed an automated agent evaluation and red-team suite measuring multi-step task success, tool selection, authorization safety, prompt-injection resistance, and latency with scenario-level evidence.
- Designed an evidence-first action architecture that separates LLM reasoning from deterministic policy enforcement and prevents unauthorized or unapproved tool execution.

## Honest limitations and next experiments

- The sample is a historical 2017–2018 research trace replayed as a live stream, not current operator data.
- Keyword retrieval is intentionally inspectable; a useful next experiment is comparing it with embedding retrieval using the same evaluation set.
- The included prompt-injection detector is a baseline. Production work needs layered isolation, data-flow controls, model-based detection, sandboxing, and continuous adversarial testing.
- SQLite and in-process action state suit a prototype. A distributed deployment would require durable queues, centralized identity, policy-as-code, idempotency, rate limits, and cryptographically verifiable logs.
