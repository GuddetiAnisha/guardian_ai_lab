# Dataset provenance

This project uses one trace from the Kaggle dataset [4G LTE Speed Dataset and Bandwidth](https://www.kaggle.com/datasets/aeryss/lte-dataset), distributed under **CC BY-SA 4.0**.

The trace dataset accompanies:

> D. Raca, J. J. Quinlan, A. H. Zahran, and C. J. Sreenan, “Beyond Throughput: a 4G LTE Dataset with Channel and Context Metrics,” ACM MMSys 2018.

The included sample is `Dataset/bus/A_2017.11.30_16.48.26.csv`. It contains one-second mobile network measurements such as RSRP, RSRQ, SNR, CQI, downlink/uplink throughput, cell identifier, mobility, and serving-cell distance.

The source records are historical—not a live operator feed. Telecom Guardian replays their original order as a live stream so the event-processing and agent workflow can be demonstrated reproducibly. No Ericsson, customer, subscriber, or production-network data is included.

Dataset files retain their original CC BY-SA 4.0 terms. Project source code is covered by the repository's MIT license.
